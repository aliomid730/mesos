#!/bin/bash
#DATE: Jun 02, 2015
#Author: Sayyed Ali Agha Hashimi
#Purpose: CloudStack & KVM Installation and configuration on ubuntu 14.04 64 bit
#Note: This script must be ran on the CloudStack server.
# Enjoy! :)
service apparmor teardown
apt-get install bridge-utils
cp /etc/network/interfaces /etc/network/interfaces.orig
cat >/etc/network/interfaces <<EOM
auto lo
iface lo inet loopback

auto eth0
iface eth0 inet manual
# Public network
auto cloudbr0
iface cloudbr0 inet static
address 10.200.200.5
netmask 255.255.255.0
gateway 10.200.200.254
dns-nameservers 10.200.200.254
dns-search cloud.local
bridge_ports eth0
bridge_fd 5
bridge_stp off
bridge_maxwait 1

# Private network
auto cloudbr1
iface cloudbr1 inet manual
bridge_ports none
bridge_fd 5
bridge_stp off
bridge_maxwait 1
EOM
reboot

cat >/etc/apt/sources.list.d/cloudstack.list <<EOM
deb http://cloudstack.apt-get.eu/ubuntu trusty 4.4
EOM
wget -O - http://cloudstack.apt-get.eu/release.asc|apt-key add -
apt-get update

apt-get --yes install cloudstack-management
apt-get --yes install mysql-server

cat >>/etc/mysql/conf.d/cloudstack.cnf <<EOM
[mysqld]
innodb_rollback_on_timeout=1
innodb_lock_wait_timeout=600
max_connections=350
log-bin=mysql-bin
binlog-format = 'ROW'
EOM
service mysql restart


cat >/tmp/CLOUDSTACK-8157.diff <<'EOM'
--- /usr/share/cloudstack-management/setup/create-schema-premium.sql.
+++ /usr/share/cloudstack-management/setup/create-schema-premium.sql
@@ -296,7 +296,7 @@
`password` varchar(200) COMMENT 'password',
`round_robin_marker` int COMMENT 'This marks the volume to be pick
PRIMARY KEY (`id`),
- CONSTRAINT `fk_netapp_volume__pool_id` FOREIGN KEY `fk_netapp_volu
+ CONSTRAINT `fk_netapp_volume__pool_id` FOREIGN KEY `fk_netapp_volu
INDEX `i_netapp_volume__pool_id`(`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
@@ -315,7 +315,7 @@
`size` bigint NOT NULL COMMENT 'lun size',
`volume_id` bigint unsigned NOT NULL COMMENT 'parent volume id',
PRIMARY KEY (`id`),
- CONSTRAINT `fk_netapp_lun__volume_id` FOREIGN KEY `fk_netapp_lun__
+ CONSTRAINT `fk_netapp_lun__volume_id` FOREIGN KEY `fk_netapp_lun__
INDEX `i_netapp_lun__volume_id`(`volume_id`),
INDEX `i_netapp_lun__lun_name`(`lun_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
EOM
cp /usr/share/cloudstack-management/setup/create-schema-premium.sql /usr/share/cloudstack-management/setup/create-schema-premium.sql.orig
sudo apt-get install patch
patch -d / -p0 -u -i /tmp/CLOUDSTACK-8157.diff

cloudstack-setup-databases cloud:cloud@localhost --deploy-as=root:Paccw0rd

mkdir -p /export/primary /export/secondary
apt-get install nfs-kernel-server
cat >>/etc/exports <<EOM
/export *(rw,async,no_root_squash,no_subtree_check)
EOM
exportfs -a

apt-get install nfs-common
cp /etc/default/nfs-common /etc/default/nfs-common.orig
sed -i '/NEED_STATD=/ a NEED_STATD=yes' /etc/default/nfs-common
sed -i '/STATDOPTS=/ a STATDOPTS="--port 662 --outgoing-port 2020"' /etc/default/nfs-common
diff -du /etc/default/nfs-common.orig /etc/default/nfs-common

cat >> /etc/modprobe.d/lockd.conf <<EOM
options lockd nlm_udpport=32769 nlm_tcpport=32803
EOM

service nfs-kernel-server restart
# test:
showmount -e 127.0.0.1

IP=10.200.200.5
mkdir -p /mnt/primary /mnt/secondary
cat >>/etc/fstab <<EOM
$IP:/export/primary /mnt/primary nfs rsize=8192,wsize=8192,timeo=14,intr,vers=3,noauto	0	2
$IP:/export/secondary /mnt/secondary nfs rsize=8192,wsize=8192,timeo=14,intr,vers=3,noauto	0	2
EOM
mount /mnt/primary
mount /mnt/secondary


apt-get install cloudstack-agent
cp /etc/libvirt/libvirtd.conf /etc/libvirt/libvirtd.conf.orig
sed -i '/#listen_tls = 0/ a listen_tls = 0' /etc/libvirt/libvirtd.conf
sed -i '/#listen_tcp = 1/ a listen_tcp = 1' /etc/libvirt/libvirtd.conf
sed -i '/#tcp_port = "16509"/ a tcp_port = "16509"' /etc/libvirt/libvirtd.conf
sed -i '/#auth_tcp = "sasl"/ a auth_tcp = "none"' /etc/libvirt/libvirtd.conf
diff -du /etc/libvirt/libvirtd.conf.orig /etc/libvirt/libvirtd.conf

cp /etc/default/libvirt-bin /etc/default/libvirt-bin.orig
sed -i -e 's/libvirtd_opts="-d"/libvirtd_opts="-d -l"/' /etc/default/libvirt-bin
diff -du /etc/default/libvirt-bin.orig /etc/default/libvirt-bin
service libvirt-bin restart

cp /etc/libvirt/qemu.conf /etc/libvirt/qemu.conf.orig
sed -i '/# vnc_listen = "0.0.0.0"/ a vnc_listen = "0.0.0.0"' /etc/libvirt/qemu.conf
diff -du /etc/libvirt/qemu.conf.orig /etc/libvirt/qemu.conf
service libvirt-bin restart

ln -s /etc/apparmor.d/usr.sbin.libvirtd /etc/apparmor.d/disable/
ln -s /etc/apparmor.d/usr.lib.libvirt.virt-aa-helper /etc/apparmor.d/
apparmor_parser -R /etc/apparmor.d/usr.sbin.libvirtd
apparmor_parser -R /etc/apparmor.d/usr.lib.libvirt.virt-aa-helper
service libvirt-bin restart

ufw allow proto tcp from any to any port 22
ufw allow proto tcp from any to any port 1798
ufw allow proto tcp from any to any port 16509
ufw allow proto tcp from any to any port 5900:6100
ufw allow proto tcp from any to any port 49152:49216

reboot
/usr/share/cloudstack-common/scripts/storage/secondary/cloud-install-sys-tmplt -m /mnt/secondary -u http://cloudstack.apt-get.eu/systemvm/4.5/systemvm64template-4.5-kvm.qcow2.bz2 -h kvm -F
#/usr/share/cloudstack-common/scripts/storage/secondary/cloud-install-sys-tmplt -m /mnt/secondary -u http://cloudstack.apt-get.eu/systemvm/4.5/systemvm64template-4.5-xen.vhd.bz2 -h xenserver -F
service cloudstack-management start
service cloudstack-management status
service cloudstack-agent start
service cloudstack-agent status 

#ADD Gateway 10.200.200.254
#ADD DNS 10.200.200.12
#ADD POD 10.200.200.60-69
#ADD Guest Network 10.200.200.70-230
#ADD Host 10.200.200.5
#ADD Primary Storage 10.200.200.5:/export/primary
#ADD Secondary Storage 10.200.200.5:/export/secondary
#Hit Launch and pray :)
