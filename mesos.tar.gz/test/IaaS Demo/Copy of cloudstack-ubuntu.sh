#!/bin/bash
#DATE: Jun 02, 2015
#Author: Sayyed Ali Agha Hashimi
#Purpose: CloudStack Installation and configuration on ubuntu 14.04 64 bit
#Note: This script must be ran on the CloudStack server.
# Enjoy! :)
if [$UID -ne 0]; then
echo "Run as root user"
fi

service apparmor teardown
ufw disable
cp \/etc\/network\/interfaces \/etc\/network\/interfaces.orig
cat \>\/etc\/network\/interfaces <<EOM
auto lo
iface lo inet loopback

auto eth0
iface eth0 inet static
address 192.168.56.2
netmask 255.255.255.0
gateway 192.168.56.1
dns-nameservers 192.168.56.1 
dns-search cloud.local

auto eth1
iface eth1 inet static
address 10.200.200.2
netmask 255.255.255.0

auto eth2
iface eth2 inet static
address 10.100.100.2
netmask 255.255.255.0

auto eth3
iface eth3 inet static
address 10.100.101.2
netmask 255.255.255.0
EOM
cat \>\/etc\/apt\/sources.list.d\/cloudstack.list <<EOM
deb http://cloudstack.apt-get.eu/ubuntu trusty 4.5
EOM
wget -O http\:\/\/cloudstack.apt-get.eu\/release.asc|apt-key add \-
apt-get update
apt-get \-\-yes install cloudstack-management
apt-get \-\-yes install mysql-server

cat \>\/etc\/mysql\/conf.d\/cloudstack.cnf <<EOM
[mysqld]
innodb_rollback_on_timeout=1
innodb_lock_wait_timeout=600
max_connections=350
log-bin=mysql-bin
binlog-format = 'ROW'
EOM
service mysql restart

cloudstack-setup-databases cloud\:cloud@localhost \-\-deploy-as\=root\:Paccw0rd
cloudstack-setup-management

mkdir -p \/export\/primary \/export\/secondary
apt-get install nfs-kernel-server nfs-common
cat \>\>\/etc\/exports <<EOM
/export/primary *(rw,async,no_root_squash,no_subtree_check)
/export/secondary *(rw,async,no_root_squash,no_subtree_check)
EOM
exportfs -a
service nfs-kernel-server restart
mkdir -p \/mnt\/secondary
mount -t nfs 10\.100\.101\.2\:\/export\/secondary \/mnt\/secondary
\/usr\/share\/cloudstack-common\/scripts\/storage\/secondary\/cloud-install-sys-tmplt \-m \/mnt\/secondary \-u http://cloudstack.apt-get.eu/systemvm/4.5/systemvm64template-4.5-xen.vhd.bz2 -h xenserver \-F
umount \/mnt\/secondary
\/etc\/init.d\/cloudstack-management restart
