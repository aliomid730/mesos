#!/bin/bash
#DATE: Jun 03, 2015
#Author: Sayyed Ali Agha Hashimi
#Purpose: This script is used for CloudStack reset.
#Note: This script must be ran on the CloudStack server to reset all the configurations.
# Enjoy! :)
\/etc\/init.d\/cloudstack-management stop
mysql -u root -pPaccw0rd -e 'drop database cloud;'
mysql -u root -pPaccw0rd -e 'drop database cloud_usage;'
cloudstack-setup-databases cloud:cloud\@localhost \-\-deploy-as\=root\:Paccw0rd
rm \-rf \/var\/log\/cloudstack\/management\/\*
cloudstack-setup-management
\/etc\/init.d\/cloudstack-management start