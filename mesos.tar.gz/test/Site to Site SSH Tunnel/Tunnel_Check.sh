#!/bin/bash
#DATE: April 21, 2015
#Author: Sayyed Ali Agha Hashimi
#Purpose: This script is used to check tunnel interface existence and create it if it is unavailable.
#Note: This script must be ran on the client using crontab file.
# Enjoy! :)
tunnel_id=303
root_user=root
tunnel_interface=tun303
tunnel_server_address=10.40.0.1
tunnel_client_address=10.40.0.2
ssh_server_ip=10.99.56.4
zone_subnet=10.13.62.0\/28
ntec_subnet=10.20.1.0\/24
ping -c 4 $ssh_server_ip
if [ $? -eq 0 ] ; then

	ifconfig $tunnel_interface
	if [ $? -ne 0 ] ; then
		#ssh -S /var/run/ssh-myvpn-tunnel-control -O exit $ssh_server_ip
		ssh -S /var/run/ssh-vpn-tunnel-control -M -f -w $tunnel_id\:$tunnel_id $ssh_server_ip true
		sleep 5
		#ssh $root_user\@$ssh_server ip link set $tunnel_interface up && ip address add $tunnel_server_address\/24 peer $tunnel_client_address dev $tunnel_interface && echo 1 > \/proc\/sys\/net\/ipv4\/ip_forward && ip route add $zone_subnet via $tunnel_server_address
		ssh root@10.99.56.4 ip link set $tunnel_interface up && ip address add $tunnel_server_address\/24 peer $tunnel_client_address dev $tunnel_interface && echo 1 > \/proc\/sys\/net\/ipv4\/ip_forward && ip route add $zone_subnet via $tunnel_server_address
		sleep 5
		ip link set $tunnel_interface up
		sleep 1
		ip address add $tunnel_client_address\/24 peer $tunnel_server_address dev $tunnel_interface
		echo 1 > \/proc\/sys\/net\/ipv4\/ip_forward
		ip route add $ntec_subnet via $tunnel_client_address
	else
		echo "`date` All is well and dancing"
	fi
else
wall<<EOF
`date` MoI or DASNET Network is Down, so wait until they become alive, be patient :) 
EOF
fi
